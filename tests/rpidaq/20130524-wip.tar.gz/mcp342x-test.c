#include <stdio.h>
#include <unistd.h>
#include "mcp342x.h"

int main(void)
{
    mcp342x_init();
    mcp342x_set_config(MCP342X_ADC_CH1, MCP342X_GS_X4, MCP342X_ADC_RES_16, MCP342X_OC_CONTINUOUS);
    while(1)
    {
        // X4 gain, 16-bit res, Continuous
        mcp342x_request_conversion();
        sleep(1);
        float temp = mcp342x_read_output(MCP342X_ADC_CH1);
        printf("%3.2f uV\n", temp);
    }
}
